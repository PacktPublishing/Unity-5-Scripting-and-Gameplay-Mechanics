x<-data.set(Orange)
x
lmx<-lm(Orange$age ~ Orange$circumference) 

lmx

predict(lmx)
